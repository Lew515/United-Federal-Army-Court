import discord
from discord.ext import commands
import os

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="?", intents=intents)

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user}')

@bot.command()
async def help(ctx):
    embed = discord.Embed(title="Command List", description="Here are the available commands:", color=0x2e8b57)
    embed.add_field(name="?help", value="Show this help message", inline=False)
    embed.add_field(name="?rules", value="Display server rules", inline=False)
    embed.add_field(name="?rank", value="Show user rank", inline=False)
    embed.add_field(name="?announce [message]", value="Send an announcement (admin only)", inline=False)
    embed.add_field(name="?promote @user", value="Promote a member (admin only)", inline=False)
    embed.add_field(name="?enlist", value="Enlist a new member", inline=False)
    embed.add_field(name="?ticket", value="Create a support ticket", inline=False)
    embed.add_field(name="?jaginfo", value="Info about the JAG Corps", inline=False)
    embed.add_field(name="?lawcourses", value="Show law school courses", inline=False)
    embed.add_field(name="?applyjag", value="Instructions to apply to JAG", inline=False)
    embed.add_field(name="?schedulejag", value="Upcoming JAG sessions", inline=False)
    embed.add_field(name="?casefile [#]", value="View a mock case file", inline=False)
    embed.add_field(name="?legalrank @user", value="Show legal position", inline=False)
    await ctx.send(embed=embed)

@bot.command()
async def jaginfo(ctx):
    await ctx.send("The Judge Advocate General Corps is the legal branch of the United Federal Army. Officers are trained in military law and handle legal operations across divisions.")

@bot.command()
async def lawcourses(ctx):
    await ctx.send("📚 Available Law Courses:\n- Military Justice 101\n- Court Martial Procedures\n- Legal Ethics in Combat Zones\n- Advanced JAG Tactics")

@bot.command()
async def applyjag(ctx):
    await ctx.send("To apply to the JAG Corps, please fill out the form at: [Insert Application Link Here]")

@bot.command()
async def schedulejag(ctx):
    await ctx.send("🗓️ Upcoming JAG Sessions:\n- Law School Intro: Saturday 6 PM EST\n- Mock Trial: Sunday 5 PM EST\n- Ethics Briefing: Monday 7 PM EST")

@bot.command()
async def casefile(ctx, number: int):
    await ctx.send(f"📁 Case File #{number} Summary:\nThis is a placeholder summary for mock case file #{number}. More case data will be added here.")

@bot.command()
async def legalrank(ctx, member: discord.Member = None):
    member = member or ctx.author
    await ctx.send(f"{member.mention} currently holds the legal position: Law Student (example).")

bot.run(os.getenv("DISCORD_TOKEN"))
